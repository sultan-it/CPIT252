package atmsystem;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Atmsystem {

    public static void main(String[] args) {
        String filename = "DemoAccounts.csv";
        File file = new File(filename);

        // Check if the file exists and create demo accounts if not
        if (!file.exists()) {
            try {
                generateDemoAccounts(filename);
            } catch (IOException e) {
                System.out.println("Failed to create demo accounts: " + e.getMessage());
                return; // Exit if unable to create demo accounts
            }
        }

        AtmView view = new AtmView();
        AccountService accountService = new AccountService("DemoAccounts.csv");
        AuthService authService = new AuthService(accountService);
        TransactionService transactionService = new TransactionService(accountService);
        ATMOperationsFacade atmOperationsFacade = new ATMOperationsFacade(authService, transactionService, accountService);
        ATMController atmController = new ATMController(view, atmOperationsFacade);

        try {
            view.welcome(); // Display welcome message
            atmController.authenticateUser(); // Handle authentication including retries

            // Proceed if authentication is successful
            if (atmController.isAuthenticated()) {
                atmController.startSession(); // Start the ATM session
                while (atmController.isSessionActive()) {
                    int operation = view.promptForOperation(); // Prompt user to select an operation
                    switch (operation) {
                        case 1: // Check Balance
                            atmController.checkBalance();
                            break;
                        case 2: // Deposit Money
                            double depositAmount = view.promptForAmount("deposit");
                            atmController.depositMoney(depositAmount);
                            break;
                        case 3: // Withdraw Money
                            double withdrawAmount = view.promptForAmount("withdraw");
                            atmController.withdrawMoney(withdrawAmount);
                            break;
                        case 4: // Transfer Money
                            String targetAccountId = view.promptForTargetAccountID();
                            double transferAmount = view.promptForAmount("transfer");
                            atmController.transferMoney(targetAccountId, transferAmount);
                            break;
                        case 5: // Logout
                            atmController.endSession();
                            break;
                        default: // Handle invalid operation selection
                            view.displayMessage("Invalid operation.");
                    }
                }
            } else {
                view.displayMessage("Authentication failed.");
            }
        } finally {
            view.close(); // Ensure resources are cleaned up properly
        }
    }

    // Helper method to generate demo accounts
    private static void generateDemoAccounts(String filename) throws IOException {
        String[] accounts = {
            "ID,CardNumber,PIN,Balance",
            "1,123456,1234,1000.00",
            "2,234567,2345,1500.00",
            "3,345678,3456,2000.00",
            "4,456789,4567,2500.00",
            "5,567890,5678,3000.00",
            "6,678901,6789,3500.00",
            "7,789012,7890,4000.00",
            "8,890123,8901,4500.00",
            "9,901234,9012,5000.00",
            "10,012345,0123,5500.00"
        };
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (String account : accounts) {
                writer.println(account);
            }
        }
    }
}
