package atmsystem;

public class TransferCommand implements Command {

    private ATMOperationsFacade facade;
    private String fromAccountId;
    private String toAccountId;
    private double amount;

    public TransferCommand(ATMOperationsFacade facade, 
            String fromAccountId, String toAccountId, double amount) {
        this.facade = facade;
        this.fromAccountId = fromAccountId;
        this.toAccountId = toAccountId;
        this.amount = amount;
    }

    @Override
    public CommandResult execute() {
        boolean success = facade.transferMoney(fromAccountId, toAccountId, amount);
        return new CommandResult(success, success ? "Transfer successful." : "Transfer failed.");
    }
}
