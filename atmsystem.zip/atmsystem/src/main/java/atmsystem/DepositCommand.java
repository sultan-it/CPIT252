package atmsystem;

public class DepositCommand implements Command {

    private ATMOperationsFacade facade;
    private String accountId;
    private double amount;

    public DepositCommand(ATMOperationsFacade facade, String accountId, double amount) {
        this.facade = facade;
        this.accountId = accountId;
        this.amount = amount;
    }

    @Override
    public CommandResult execute() {
        boolean success = facade.depositMoney(accountId, amount);
        return new CommandResult(success, success ? "Deposit successful." : "Deposit failed.");
    }
}
