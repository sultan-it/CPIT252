package atmsystem;

class TransactionService {

    private AccountService accountService;

    public TransactionService(AccountService accountService) {
        this.accountService = accountService;
    }

    public boolean withdraw(String accountId, double amount) {
        AccountModel account = accountService.getAccount(accountId);
        if (account != null && account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
            accountService.saveAccounts(); 
            return true;
        }
        return false;
    }

    public boolean deposit(String accountId, double amount) {
        AccountModel account = accountService.getAccount(accountId);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountService.saveAccounts(); 
            return true;
        }
        return false;
    }

    public boolean transfer(String fromAccountId, String toAccountId, double amount) {
        AccountModel fromAccount = accountService.getAccount(fromAccountId);
        AccountModel toAccount = accountService.getAccount(toAccountId);

        if (fromAccount != null && toAccount != null && fromAccount.getBalance() >= amount) {
            boolean withdrawSuccessful = withdraw(fromAccountId, amount);
            if (withdrawSuccessful) {
                boolean depositSuccessful = deposit(toAccountId, amount);
                if (depositSuccessful) {
                    accountService.saveAccounts();
                    return true;
                } else {
                    
                    deposit(fromAccountId, amount);
                }
            }
        }
        return false;
    }
}
