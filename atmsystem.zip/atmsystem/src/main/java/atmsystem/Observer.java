package atmsystem;

public interface Observer {

    void update(Object observable, Object arg);
}
