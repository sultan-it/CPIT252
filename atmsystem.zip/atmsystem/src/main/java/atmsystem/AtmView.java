package atmsystem;

import java.util.Scanner;

public class AtmView implements Observer {

    private Scanner scanner;

    public AtmView() {
        this.scanner = new Scanner(System.in);
    }

    public void welcome() {
        System.out.println("-----------------------------------------------");
        System.out.println("*********** Welcome to our ATM system**********");
        System.out.println("-----------------------------------------------");
    }

    public String promptForCardNumber() {
        System.out.println("Enter card number:");
        return scanner.nextLine();
    }

    public String promptForPIN() {
        System.out.println("Enter PIN:");
        return scanner.nextLine();
    }

    public void displayMessage(String message) {
        System.out.println(message);
    }

    public int promptForOperation() {
        System.out.println("Select operation: 1-Check Balance, 2-Deposit, 3-Withdraw, 4-Transfer, 5-Logout");
        return Integer.parseInt(scanner.nextLine());
    }

    public double promptForAmount(String transactionType) {
        System.out.println("Enter amount to " + transactionType + ":");
        return Double.parseDouble(scanner.nextLine());
    }

    public String promptForTargetAccountID() {
        System.out.println("Enter target account ID:");
        return scanner.nextLine();
    }

    public String promptForRetry() {
        System.out.println("Would you like to try again? (yes/no)");
        return scanner.nextLine();
    }

    public void close() {
        scanner.close();
    }

    @Override
    public void update(Object observable, Object arg) {
        if (observable instanceof AccountModel) {
            AccountModel account = (AccountModel) observable;
            displayMessage("Account balance updated: " + account.getBalance());
        }
    }
}
