package atmsystem;

public interface Command {

     CommandResult execute();
}
