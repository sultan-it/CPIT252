package atmsystem;

public class AuthenticateCommand implements Command {

    private ATMOperationsFacade facade;
    private String cardNumber;
    private String pin;

    public AuthenticateCommand(ATMOperationsFacade facade, String cardNumber, String pin) {
        this.facade = facade;
        this.cardNumber = cardNumber;
        this.pin = pin;
    }

    @Override
    public CommandResult execute() {
        boolean isAuthenticated = facade.authenticateUser(cardNumber, pin);
        return new CommandResult(isAuthenticated, isAuthenticated ? 
                "Authenticated successfully." : "Authentication failed.");
    }
}
