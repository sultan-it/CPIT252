package atmsystem;

public class CheckBalanceCommand implements Command {

    private ATMOperationsFacade facade;
    private String accountId;

    public CheckBalanceCommand(ATMOperationsFacade facade, String accountId) {
        this.facade = facade;
        this.accountId = accountId;
    }

    @Override
    public CommandResult execute() {
        double balance = facade.checkBalance(accountId);
        return new CommandResult(true, "Your balance is: $" + balance);
    }
}
