package atmsystem;

public class ATMController {

    private AtmView atmView;
    private ATMOperationsFacade atmOperations;
    private volatile boolean isAuthenticated = false;
    private String currentAccountId;
    private AccountModel currentAccount;

    public ATMController(AtmView atmView, ATMOperationsFacade atmOperations) {
        this.atmView = atmView;
        this.atmOperations = atmOperations;
    }

    public void updateView(String message) {
        atmView.displayMessage(message);
    }

    public void startSession() {
        if (!ATMSessionSingleton.getInstance().isActive()) {
            ATMSessionSingleton.getInstance().startSession();
            updateView("ATM session started.");
        }
    }

    public void endSession() {
        if (ATMSessionSingleton.getInstance().isActive()) {
            ATMSessionSingleton.getInstance().endSession();
            updateView("Session ended.");
        }
    }

    public boolean isSessionActive() {
        return ATMSessionSingleton.getInstance().isActive();
    }

    public void authenticateUser() {
        while (true) {
            String cardNumber = atmView.promptForCardNumber();
            String pin = atmView.promptForPIN();
            boolean success = atmOperations.authenticateUser(cardNumber, pin);
            if (success) {
                isAuthenticated = true;
                currentAccountId = atmOperations.getCurrentAccountId();
                currentAccount = atmOperations.getAccountById(currentAccountId);
                currentAccount.addObserver(atmView);
                atmView.displayMessage("Authenticated successfully.");
                break;
            } else {
                atmView.displayMessage("Authentication failed.");
                String response = atmView.promptForRetry();
                if (!"yes".equalsIgnoreCase(response)) {
                    isAuthenticated = false;
                    atmView.displayMessage("Authentication aborted by the user.");
                    break;
                }
            }
        }
    }

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public void checkBalance() {
        if (currentAccountId != null) {
            double balance = atmOperations.checkBalance(currentAccountId);
            atmView.displayMessage("Your balance is: " + balance);
        }
    }

    public void withdrawMoney(double amount) {
        if (currentAccountId != null) {
            boolean success = atmOperations.withdrawMoney(currentAccountId, amount);
            if (success) {
                atmView.displayMessage("Withdrawal successful.");
            } else {
                atmView.displayMessage("Withdrawal failed. Check your balance.");
            }
        }
    }

    public void depositMoney(double amount) {
        if (currentAccountId != null) {
            boolean success = atmOperations.depositMoney(currentAccountId, amount);
            if (success) {
                atmView.displayMessage("Deposit successful.");
            } else {
                atmView.displayMessage("Deposit failed.");
            }
        }
    }

    public void transferMoney(String toAccountId, double amount) {
        if (currentAccountId != null) {
            boolean success = atmOperations.transferMoney(currentAccountId, toAccountId, amount);
            if (success) {
                atmView.displayMessage("Transfer successful.");
            } else {
                atmView.displayMessage("Transfer failed. Check your balance and target account ID.");
            }
        }
    }
}
