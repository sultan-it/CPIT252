package atmsystem;

public class AccountModel extends Observable {

    private String id;
    private String cardNumber; 
    private String pin;
    private double balance;

    public AccountModel(String id, String cardNumber, String pin, double balance) {
        this.id = id;
        this.cardNumber = cardNumber;
        this.pin = pin;
        this.balance = balance;
    }

    public String getId() {
        return id;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getPin() {
        return pin;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
        setChanged();
        notifyObservers(balance);
    }
}
