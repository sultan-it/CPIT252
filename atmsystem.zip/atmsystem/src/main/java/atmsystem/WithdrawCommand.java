package atmsystem;

public class WithdrawCommand implements Command {

    private ATMOperationsFacade facade;
    private String accountId;
    private double amount;

    public WithdrawCommand(ATMOperationsFacade facade, 
            String accountId, double amount) {
        this.facade = facade;
        this.accountId = accountId;
        this.amount = amount;
    }

    @Override
    public CommandResult execute() {
        boolean success = facade.withdrawMoney(accountId, amount);
        return new CommandResult(success, success ? 
                "Withdrawal successful." : "Insufficient funds.");
    }
}
