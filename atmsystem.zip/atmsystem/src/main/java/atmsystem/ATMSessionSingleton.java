package atmsystem;

public class ATMSessionSingleton {

    private static ATMSessionSingleton instance = new ATMSessionSingleton();
    private boolean active = false;

    private ATMSessionSingleton() {
    }

    public static ATMSessionSingleton getInstance() {
        return instance;
    }

    public boolean isActive() {
        return active;
    }

    public void startSession() {
        if (!active) {
            active = true;
        }
    }

    public void endSession() {
        if (active) {
            active = false;
        }
    }
}
